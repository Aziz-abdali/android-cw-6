package com.example.w6;

public class Movie {
    private String title;
    private String mainActor;
    private String genre;
    private Double movieRote;
    private int pgRote;

    public Movie(String title, String mainActor, String genre, Double movieRote, int pgRote) {
        this.title = title;
        this.mainActor = mainActor;
        this.genre = genre;
        this.movieRote = movieRote;
        this.pgRote = pgRote;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMainActor() {
        return mainActor;
    }

    public void setMainActor(String mainActor) {
        this.mainActor = mainActor;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Double getMovieRote() {
        return movieRote;
    }

    public void setMovieRote(Double movieRote) {
        this.movieRote = movieRote;
    }

    public int getPgRote() {
        return pgRote;
    }

    public void setPgRote(int pgRote) {
        this.pgRote = pgRote;
    }
}
