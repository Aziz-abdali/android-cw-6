package com.example.w6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Movie x=new Movie("goker","goker","a crime", 1.0 ,22);
        Movie y=new Movie("Dark","yousef","action", 1.5 ,6);


    }



}



